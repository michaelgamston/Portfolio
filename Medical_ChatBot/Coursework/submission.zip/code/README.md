# File structure 

data/ - this contains all the databases produced for training and the medical dataset used for records.
models/ - this contains all the trained SVM models and the vectoriser. 
responses/ - this contains JSON files with a selection of different responses for Marvin to use. 
test_data/ - this contains the databases produced for testing the trained models.
changes_for_review.json - this file contains any changes the user has request to make. 
data_exploration.ipynb - this file contains the intail data exploration of the downloaded medical dataset
main.py - this file contains the code to run Marvin 
mode_experiments.ipynb - this file contains the intial expirements that were run to find which model type to use 
model_trainer_and_tests.ipynb - this file contains the code to train each SVM used and then test it.

# Comments 

If you wish to try this Marvin out please do. Find some user details from data/processed_health_data.csv and try it out. 
You'll see that the dataset uses ages and not dates of birth, so provided you supply a date of birth that matches the age of the person you've choosen you won't run into any issues.

I use - bobby jackson - 11 april 1995 

accessable medical records - Name,Age,Gender,Blood Type,Medical Condition,Date of Admission,Doctor,Hospital,Insurance Provider,Billing Amount,Room Number,Admission Type,Discharge Date,Medication,Test Results